const closureDraw = (function () {

  const canvas = document.querySelector('canvas');
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  let isDrawing = false;

  canvas.addEventListener('mousedown', (event) => {
    event.stopPropagation();
    isDrawing = true;
  });

  canvas.addEventListener('mouseup', (event) => {
    event.stopPropagation();
    isDrawing = false;
  });

  canvas.addEventListener('mousemove', (event) => {
    event.stopPropagation();
    if (!isDrawing) return;

    // https://www.geeksforgeeks.org/how-to-get-the-coordinates-of-a-mouse-click-on-a-canvas-element/
    // https://zellwk.com/blog/css-translate-values-in-javascript/
    // https://roblouie.com/article/617/transforming-mouse-coordinates-to-canvas-coordinates/
    // https://stackoverflow.com/questions/40753016/mouse-coordinates-on-canvas-after-css-scale

    // getBoundingClientRect retorna as dimensoes e posições do elemento após a transformação do CSS, ou seja, considera o que realmente é exibido na tela
    // https://stackoverflow.com/questions/27745438/how-to-compute-getboundingclientrect-without-considering-transforms
    const rect = canvas.getBoundingClientRect();

    // calcula a diferença da posição do mouse na view do elemento canvas
    const mouse = {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top
    }

    // scale mouse coordinates (real) to canvas coordinates (locate coordinates)
    // escala as coordenadas do mouse para as coordenadas do elemento (canvas), neste caso, coordenadas locais eu acho
    mouse.x = mouse.x * (canvas.width / rect.width);
    mouse.y = mouse.y * (canvas.height / rect.height);

    const brush = {
      size: 4,
      color: 'red'
    }
    ctx.fillStyle = brush.color;
    ctx.fillRect(mouse.x - (brush.size / 2), mouse.y - (brush.size / 2), 4, 4);

  });
})()
