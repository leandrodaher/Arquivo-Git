var canvas = document.querySelector('canvas');
var ctx = canvas.getContext('2d');

ctx.fillStyle = '#ffffff';
ctx.fillRect(0, 0, canvas.width, canvas.height);

var containerRef = document.querySelector('.zoom-container');

var isPanning = false;
var image = canvas;
var position = {
  oldX: 0,
  oldY: 0,
  x: 0,
  y: 0,
  z: 1,
}

var onMouseDown = (e) => {
  e.preventDefault();
  isPanning = true;
  position = {
    ...position,
    oldX: e.clientX,
    oldY: e.clientY
  };
};

var onWheel = (e) => {
  if (e.deltaY) {
    const sign = Math.sign(e.deltaY) / 10;
    const scale = 1 - sign;
    const rect = containerRef.getBoundingClientRect();

    position = {
      ...position,
      x: position.x * scale - (rect.width / 2 - e.clientX + rect.x) * sign,
      y: position.y * scale - (image.height * rect.width / image.width / 2 - e.clientY + rect.y) * sign,
      z: position.z * scale,
    };
  }
};



function init() {
  const mouseup = () => {
    isPanning = false;
  };

  const mousemove = (event) => {
    if (isPanning) {
      position = {
        ...position,
        x: position.x + event.clientX - position.oldX,
        y: position.y + event.clientY - position.oldY,
        oldX: event.clientX,
        oldY: event.clientY,
      };
    }
  };

  containerRef.addEventListener('mousedown', onMouseDown);
  containerRef.addEventListener('mousewheel', onWheel)
  window.addEventListener('mouseup', mouseup);
  window.addEventListener('mousemove', mousemove);
}

setInterval(() => {
  const transform = document.querySelector('#transform');
  transform.style.transform = `translate(${position.x}px, ${position.y}px) scale(${position.z})`;
}, 10);

init();
